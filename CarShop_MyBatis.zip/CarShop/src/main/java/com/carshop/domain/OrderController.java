package com.carshop.domain;

import org.springframework.stereotype.Controller;

@Controller
public class OrderController {
	
	//Order 컨트롤러는 실제 작동하지는 않는다. webflow가 주문처리를 담당한다.
	
	
	
	
}
