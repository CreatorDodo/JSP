package com.carshop.board;

import java.util.*;

public interface BoardService {
	
	List<BoardDTO> getAllBoardList();
}
